const apis ={
    getCustomerInfo: 'http://localhost/store_v1/client/api/get_customer_info.php?customer_id='
}


export default apis;